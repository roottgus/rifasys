// resources/js/stores/modalVentaTicket.js

import { useApi } from '../helpers/api';
import clientStore from './clientStore';
import validationStore from './validationStore';

export default function modalVentaTicketStore() {
  return {
    // 0) API client
    api: useApi(),

    // 1) Cliente y validación
    ...clientStore(),
    ...validationStore(),

    metodosPagoActivos: window.metodosPagoActivos || [],
    metodoPago: '',

    pagoDatos: {
      fecha: '',
      referencia: '',
      titular_reporte: '',
      monto_reporte: '',
      banco_reporte: '',
      oficina_o_punto: '',
      comentarios: ''
    },

    errorReferencia: '',
    referenciaVerificando: false,
    errorFecha: '',

    reportConfigs: {
      'tran_bancaria_nacional': [
        { key: 'fecha',           label: 'Fecha de Pago',     type: 'date' },
        { key: 'referencia',      label: 'Referencia',        type: 'text' },
        { key: 'titular_reporte', label: 'Titular (Cliente)', type: 'text' },
        { key: 'monto_reporte',   label: 'Monto Pagado',      type: 'number' }
      ],
      'tran_bancaria_internacional': [
        { key: 'fecha',         label: 'Fecha de Pago',    type: 'date' },
        { key: 'referencia',    label: 'Referencia',       type: 'text' },
        { key: 'monto_reporte', label: 'Monto Pagado',     type: 'number' }
      ],
      'pago_movil': [
        { key: 'fecha',         label: 'Fecha de Pago',    type: 'date' },
        { key: 'referencia',    label: 'Referencia',       type: 'text' },
        { key: 'monto_reporte', label: 'Monto Pagado',     type: 'number' }
      ],
      'zelle': [
        { key: 'fecha',           label: 'Fecha de Pago',        type: 'date' },
        { key: 'referencia',      label: 'Referencia (Email)',   type: 'text' },
        { key: 'titular_reporte', label: 'Titular (Cliente)',    type: 'text' },
        { key: 'monto_reporte',   label: 'Monto Pagado',         type: 'number' }
      ],
      'pago_efectivo': [
        { key: 'fecha',         label: 'Fecha de Pago',    type: 'date' },
        { key: 'monto_reporte', label: 'Monto Pagado',     type: 'number' },
        {
          key: 'oficina_o_punto',
          label: 'Lugar de Pago',
          type: 'select',
          options: [
            { value: 'oficina',     label: 'En la oficina' },
            { value: 'punto_calle', label: 'Punto de calle' }
          ]
        }
      ]
    },

    get reportFields() {
      return this.reportConfigs[this.metodoPago] || [];
    },

    get hoyStr() {
      const hoy = new Date();
      const mes = String(hoy.getMonth() + 1).padStart(2, '0');
      const dia = String(hoy.getDate()).padStart(2, '0');
      return `${hoy.getFullYear()}-${mes}-${dia}`;
    },

    seleccionarMetodoPago(mpKey) {
      this.metodoPago = mpKey;
      this.pagoDatos = {
        fecha: '', referencia: '', titular_reporte: '', monto_reporte: '',
        banco_reporte: '', oficina_o_punto: '', comentarios: ''
      };
      const metodo = this.metodosPagoActivos.find(m => m.key === mpKey);
      if (metodo && metodo.fields) {
        const bancoField = metodo.fields.find(f => f.key === 'banco');
        if (bancoField && bancoField.value) {
          this.pagoDatos.banco_reporte = bancoField.value;
        }
      }
      this.errorPago = '';
      this.errorReferencia = '';
      this.errorFecha = '';
    },

    obtenerDetallesMetodo() {
      const mp = this.metodosPagoActivos.find(m => m.key === this.metodoPago);
      return mp
        ? {
            name:        mp.name,
            descripcion: mp.descripcion || '',
            fields:      mp.fields || [],
            icon:        mp.icon || '',
            info:        mp.info || ''
          }
        : { name: '', descripcion: '', fields: [], icon: '', info: '' };
    },

    async validarReferenciaUnica() {
      this.errorReferencia = '';
      if (!this.pagoDatos.referencia) {
        this.referenciaVerificando = false;
        return;
      }
      this.referenciaVerificando = true;
      try {
        const ref = this.pagoDatos.referencia.trim();
        if (!ref) {
          this.referenciaVerificando = false;
          return;
        }
        const res = await fetch(`/test/validar-referencia?referencia=${encodeURIComponent(ref)}`);
        const json = await res.json();
        this.errorReferencia = json.existe
          ? '⚠️ Esta referencia ya fue utilizada en otro pago o abono.'
          : '';
      } catch {
        this.errorReferencia = 'No se pudo validar la referencia.';
      }
      this.referenciaVerificando = false;
    },

    validarFechaPago() {
      this.errorFecha = '';
      if (this.pagoDatos.fecha) {
        const hoy = new Date();
        const fechaPago = new Date(this.pagoDatos.fecha);
        hoy.setHours(0,0,0,0);
        fechaPago.setHours(0,0,0,0);
        if (fechaPago > hoy) {
          this.errorFecha = 'No puedes seleccionar una fecha futura.';
        }
      }
    },

    // --- NUEVO: SELECCIÓN MÚLTIPLE ---
    pickedTickets: [], // Tickets seleccionados (array)

    get totalAPagar() {
  if (!this.pickedTickets.length) return 0;
  // Suma como número
  return this.pickedTickets.reduce((acc, t) => acc + Number(t.precio_ticket || 0), 0);
},



    addTicket(ticket) {
      if (!this.pickedTickets.some(t => t.id === ticket.id)) {
        this.pickedTickets.push(ticket);
      }
    },

    removeTicket(ticket) {
      this.pickedTickets = this.pickedTickets.filter(t => t.id !== ticket.id);
    },

    toggleTicket(ticket) {
      if (this.pickedTickets.some(t => t.id === ticket.id)) {
        this.removeTicket(ticket);
      } else {
        this.addTicket(ticket);
      }
    },

    clearTickets() {
      this.pickedTickets = [];
    },

    openVentaSeleccionados() {
      if (!this.pickedTickets.length) return;
      this.modalOpen = true;
      this.paso = 1;
      this.accion = 'vender';
      this.picked = this.pickedTickets; // es un array de tickets
      this.resetCliente();
      this.montoAbono = '';
      this.metodoPago = '';
      this.pagoDatos = { fecha: '', referencia: '', titular_reporte: '', monto_reporte: '', banco_reporte: '', oficina_o_punto: '', comentarios: '' };
      this.ventaExitosa = false;
      this.mensajeExito = '';
      this.accionRealizada = '';
      this.errorMensaje = '';
      this.errorPago = '';
      this.errorReferencia = '';
      this.errorFecha = '';
      this.validacion = {
        cedula: null, email: null, telefono: null,
        loading: { cedula: false, email: false, telefono: false },
        mensaje: { cedula: '', email: '', telefono: '' },
        conflicto: { cedula: false, email: false, telefono: false },
        errorGlobal: ''
      };
    },

    // --- FIN DE SELECCIÓN MÚLTIPLE ---

    modalOpen: false,
    paso: 1,
    picked: null,
    padLen: 3,

    accion: 'vender',
    operaciones: [
      {
        value: 'vender',
        label: 'Venta Total',
        icon: 'fas fa-cash-register',
        selectedClass: 'bg-indigo-600 text-white shadow-lg',
        unselectedClass: 'bg-indigo-50 text-indigo-700 border border-indigo-200'
      },
      {
        value: 'apartado',
        label: 'Apartado',
        icon: 'fas fa-hourglass-half',
        selectedClass: 'bg-orange-500 text-white shadow-lg',
        unselectedClass: 'bg-orange-50 text-orange-700 border border-orange-200'
      },
      {
        value: 'abono',
        label: 'Abono Inicial',
        icon: 'fas fa-coins',
        selectedClass: 'bg-purple-600 text-white shadow-lg',
        unselectedClass: 'bg-purple-50 text-purple-700 border border-purple-200'
      }
    ],

    montoAbono: '',
    ventaExitosa: false,
    mensajeExito: '',
    accionRealizada: '',

   open(tickets) {
  this.modalOpen = true;
  this.paso = 1;
  this.accion = 'vender';

  // tickets siempre será un array (verifica esto donde disparas el evento)
  this.pickedTickets = Array.isArray(tickets) ? tickets : [tickets];
  this.picked = this.pickedTickets[0] || null; // solo si necesitas uno puntual para inputs

  this.resetCliente();
  this.montoAbono = '';
  this.metodoPago = '';
  this.pagoDatos = { fecha: '', referencia: '', titular_reporte: '', monto_reporte: '', banco_reporte: '', oficina_o_punto: '', comentarios: '' };
  this.ventaExitosa = false;
  this.mensajeExito = '';
  this.accionRealizada = '';
  this.errorMensaje = '';
  this.errorPago = '';
  this.errorReferencia = '';
  this.errorFecha = '';
  this.validacion = {
    cedula: null, email: null, telefono: null,
    loading: { cedula: false, email: false, telefono: false },
    mensaje: { cedula: '', email: '', telefono: '' },
    conflicto: { cedula: false, email: false, telefono: false },
    errorGlobal: ''
  };
},

    closeModal() {
      this.modalOpen = false;
      this.picked = null;
      this.ventaExitosa = false;
      this.mensajeExito = '';
      this.accionRealizada = '';
      this.metodoPago = '';
      this.pagoDatos = { fecha: '', referencia: '', titular_reporte: '', monto_reporte: '', banco_reporte: '', oficina_o_punto: '', comentarios: '' };
      this.paso = 1;
      this.montoAbono = '';
      this.errorReferencia = '';
      this.errorFecha = '';
      this.clearTickets(); // limpia selección múltiple
      if (typeof this.resetCliente === "function") this.resetCliente();
      this.validacion = {
        cedula: null, email: null, telefono: null,
        loading: { cedula: false, email: false, telefono: false },
        mensaje: { cedula: '', email: '', telefono: '' },
        conflicto: { cedula: false, email: false, telefono: false },
        errorGlobal: ''
      };
      document.body.style.overflow = '';
    },

    irAPago() {
      this.errorMensaje = '';
      if (!this.camposRequeridosCompletos()) {
        this.errorMensaje = 'Debes completar y validar todos los campos obligatorios antes de continuar.';
        return;
      }
      if (this.accion === 'vender' || this.accion === 'abono') {
        this.paso = 2;
        this.errorPago = '';
      } else {
        this.procesarVenta();
      }
    },

    async procesarVenta() {
      // Validaciones de cliente y paso 2…
      if (this.paso === 2) {
        this.validarFechaPago();
        if (this.errorFecha) {
          this.errorPago = this.errorFecha;
          return;
        }
        if (this.errorReferencia || this.referenciaVerificando) {
          this.errorPago = this.errorReferencia || 'Esperando validación de referencia...';
          return;
        }
        if (!this.validarPago(this.reportFields, this.pagoDatos)) return;
      }
      if (
        this.validacion.cedula === false ||
        this.validacion.email === false ||
        this.validacion.telefono === false ||
        this.validacion.conflicto.cedula ||
        this.validacion.conflicto.email ||
        this.validacion.conflicto.telefono
      ) {
        this.errorMensaje = 'Revisa los campos destacados, corrige antes de continuar.';
        return;
      }

      // --- AJUSTE PARA VENTA MÚLTIPLE ---
      let ticket_ids = [];
      if (Array.isArray(this.picked)) {
        ticket_ids = this.picked.map(t => t.id);
      } else if (this.picked && this.picked.id) {
        ticket_ids = [this.picked.id];
      }

      const detallesMetodo = this.obtenerDetallesMetodo();
      const cuentaDestino = {};
      detallesMetodo.fields.forEach(f => {
        cuentaDestino[f.key] = f.value;
      });

      const payload = {
        ticket_ids: ticket_ids,
        accion: this.accion,
        cliente: this.cliente,
        monto_abono: this.montoAbono,
        metodo_pago: this.metodoPago,
        pago_datos: this.pagoDatos,
        cuenta_admin_destino: cuentaDestino,
        total_pago: this.totalAPagar
      };

      try {
        const res = await this.api.call('/admin/tickets/procesar-venta', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
          },
          body: JSON.stringify(payload)
        });

        // useApi returns the Response object
        if (!res.ok) {
          const text = await res.text();
          console.error('HTTP Error:', res.status, text);
          this.errorPago = 'Error interno del servidor.';
          return;
        }

        let data;
        try {
          data = await res.json();
        } catch (e) {
          console.error('JSON inválido:', e);
          this.errorPago = 'Respuesta inválida del servidor.';
          return;
        }

        if (data.success) {
          this.picked = data.ticket;
          this.ventaExitosa = true;
          this.mensajeExito = data.mensaje || 'Venta realizada exitosamente';
          this.accionRealizada = this.accion;

          window.dispatchEvent(new CustomEvent('ultima-venta-ticket', {
            detail: {
              ticket: Array.isArray(this.picked) ? this.picked.map(t=>t.numero).join(', ') : this.picked.numero || '',
              tipo: this.accionRealizada === 'vender'
                ? 'Venta Total'
                : this.accionRealizada === 'apartado'
                  ? 'Apartado'
                  : 'Abono'
            }
          }));

          window.dispatchEvent(new Event('tickets:reload'));
        } else {
          if (data.campo && ['cedula', 'email', 'telefono'].includes(data.campo)) {
            this.validacion[data.campo] = false;
            this.validacion.mensaje[data.campo] = data.mensaje || 'Error';
            this.validacion.conflicto[data.campo] = true;
            this.errorMensaje = '';
          } else {
            this.errorPago = data.mensaje || 'Ocurrió un error al procesar la venta';
          }
        }
      } catch (e) {
        console.error('Error procesarVenta():', e);
        this.errorPago = 'Error de red o de servidor';
      }
    }
  };
}

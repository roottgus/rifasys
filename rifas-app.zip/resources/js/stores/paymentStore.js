// resources/js/stores/paymentStore.js

export default function paymentStore() {
  return {
    // Lista de métodos de pago activos (inyectada desde Blade via window.metodosPagoActivos)
    metodosPagoActivos: window.metodosPagoActivos || [],

    // Clave del método seleccionado
    metodoPago: '',

    // Objeto en el que se guardan los valores que el admin reporta para cada método
    pagoDatos: {
      fecha: '',
      referencia: '',
      titular_reporte: '',
      monto_reporte: '',
      banco_reporte: '',
      oficina_o_punto: '',
      comentarios: ''
    },

    /**
     * Configuración de campos que el administrador debe rellenar
     * según el método escogido.  
     * Cada entrada en el objeto es un array de campos:
     *   { key, label, type, [options] }
     */
    get reportConfigs() {
      return {
        'tran_bancaria_nacional': [
          { key: 'fecha',           label: 'Fecha de Pago',     type: 'date' },
          { key: 'banco_reporte',   label: 'Banco (Cliente)',   type: 'text' },
          { key: 'referencia',      label: 'Referencia',        type: 'text' },
          { key: 'titular_reporte', label: 'Titular (Cliente)', type: 'text' },
          { key: 'monto_reporte',   label: 'Monto Pagado',      type: 'number' }
        ],
        'tran_bancaria_internacional': [
          { key: 'fecha',         label: 'Fecha de Pago',    type: 'date' },
          { key: 'referencia',    label: 'Referencia',       type: 'text' },
          { key: 'monto_reporte', label: 'Monto Pagado',     type: 'number' },
          { key: 'banco_reporte', label: 'Banco (Cliente)',  type: 'text' }
        ],
        'pago_movil': [
          { key: 'fecha',         label: 'Fecha de Pago',    type: 'date' },
          { key: 'referencia',    label: 'Referencia',       type: 'text' },
          { key: 'monto_reporte', label: 'Monto Pagado',     type: 'number' }
        ],
        'zelle': [
          { key: 'fecha',           label: 'Fecha de Pago',        type: 'date' },
          { key: 'referencia',      label: 'Referencia (Email)',   type: 'text' },
          { key: 'titular_reporte', label: 'Titular (Cliente)',    type: 'text' },
          { key: 'monto_reporte',   label: 'Monto Pagado',         type: 'number' }
        ],
        'pago_efectivo': [
          { key: 'fecha',         label: 'Fecha de Pago',    type: 'date' },
          { key: 'monto_reporte', label: 'Monto Pagado',     type: 'number' },
          {
            key: 'oficina_o_punto',
            label: 'Lugar de Pago',
            type: 'select',
            options: [
              { value: 'oficina',     label: 'En la oficina' },
              { value: 'punto_calle', label: 'Punto de calle' }
            ]
          }
        ]
      };
    },

    /**
     * Retorna solo el arreglo de campos que deben rellenarse
     * para el método actual (o [] si ninguno está seleccionado).
     */
    get reportFields() {
      return this.reportConfigs[this.metodoPago] || [];
    },

    /**
     * Cuando el admin selecciona un método de pago:
     * - Asigna this.metodoPago
     * - Reinicia todo this.pagoDatos para evitar datos viejos
     * - Imprime en consola el arreglo real de reportFields
     */
    seleccionarMetodoPago(mpKey) {
      this.metodoPago = mpKey;

      // Inicializamos todos los campos de pagoDatos en blanco
      this.pagoDatos = {
        fecha: '',
        referencia: '',
        titular_reporte: '',
        monto_reporte: '',
        banco_reporte: '',
        oficina_o_punto: '',
        comentarios: ''
      };

      this.errorPago = '';

      // —————— Depuración en consola ——————
      console.log('▶ método seleccionado:', mpKey);
      console.log('▶ reportConfigs:', this.reportConfigs);
      console.log('▶ reportFields (Proxy view):', this.reportFields);
      // Para ver el contenido real como array, deserializamos:
      console.log('▶ reportFields (contenido real):', JSON.parse(JSON.stringify(this.reportFields)));
      // ————————————————————————————
    },

    /**
     * Devuelve los detalles de la empresa (name, description, icon, fields)
     * para el método actualmente seleccionado.
     */
    obtenerDetallesMetodo() {
      const mp = this.metodosPagoActivos.find(m => m.key === this.metodoPago);
      if (!mp) return null;
      return {
        name:        mp.name,
        descripcion: mp.descripcion || '',
        fields:      mp.fields || [],     
        icon:        mp.icon || '',
        info:        mp.info || ''
      };
    }
  };
}

<x-filament::page>
    {{ $this->form }}
    <x-filament::button wire:click="submit" class="mt-4">
        Vender Tickets
    </x-filament::button>
</x-filament::page>

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login | {{ config('app.name') }}</title>

  <!-- Tipografía moderna -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

  @vite(['resources/css/app.css', 'resources/js/app.js'])
  <style>
    body { font-family: 'Inter', sans-serif; }
    .fade-in { animation: fadeIn 0.7s cubic-bezier(.47,1.64,.41,.8) both; }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(32px);}
      to   { opacity: 1; transform: translateY(0);}
    }
    .input-error { border-color: #f87171 !important; }
    .input-icon { transition: color .2s; }
    .input:focus ~ .input-icon { color: #fb923c; }
  </style>
</head>
<body class="min-h-screen flex bg-gradient-to-br from-gray-100 to-orange-50">

  {{-- Panel Izquierdo con imagen y branding --}}
  <aside class="hidden lg:flex w-1/2 relative overflow-hidden">
    <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('/images/login-bg.jpg');"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-orange-600/80 to-orange-900/80"></div>
    <div class="relative m-auto text-center px-12 fade-in text-white z-10">
      <img src="/images/logo.png" alt="Logo" class="mx-auto w-32 mb-6 drop-shadow-2xl">
      <h1 class="text-5xl font-extrabold mb-4 drop-shadow">Bienvenido</h1>
      <p class="text-xl font-medium drop-shadow">Gestiona tus rifas, tickets y pagos de forma rápida y segura.</p>
      <div class="mt-16 opacity-60 text-xs tracking-widest">Sistema Profesional de Gestión</div>
    </div>
  </aside>

  {{-- Formulario de Login --}}
  <main class="flex w-full lg:w-1/2 justify-center items-center p-4 sm:p-8">
    <div class="w-full max-w-md bg-white rounded-3xl shadow-2xl p-8 md:p-10 fade-in relative">

      <h2 class="text-3xl font-extrabold text-gray-800 mb-8 text-center tracking-tight">Iniciar Sesión</h2>

      <!-- Session Status -->
      <x-auth-session-status class="mb-4" :status="session('status')" />

      <form method="POST" action="{{ route('login') }}" class="space-y-6" id="loginForm" autocomplete="on">
        @csrf

        {{-- Email --}}
        <div class="relative">
          <label for="email" class="sr-only">Correo electrónico</label>
          <input
            id="email"
            name="email"
            type="email"
            required
            autofocus
            class="input w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg
                   focus:outline-none focus:ring-2 focus:ring-orange-500
                   transition-shadow duration-200 hover:shadow-md
                   @error('email') input-error @enderror"
            placeholder="Correo electrónico"
            autocomplete="username"
            aria-label="Correo electrónico"
          >
          <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none input-icon">
            <i class="fas fa-envelope"></i>
          </span>
          <x-input-error :messages="$errors->get('email')" class="mt-2 text-sm text-red-600" />
        </div>

        {{-- Contraseña --}}
        <div class="relative">
          <label for="password" class="sr-only">Contraseña</label>
          <input
            id="password"
            name="password"
            type="password"
            required
            class="input w-full pl-11 pr-12 py-3 border border-gray-300 rounded-lg
                   focus:outline-none focus:ring-2 focus:ring-orange-500
                   transition-shadow duration-200 hover:shadow-md
                   @error('password') input-error @enderror"
            placeholder="Contraseña"
            autocomplete="current-password"
            aria-label="Contraseña"
          >
          <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none input-icon">
            <i class="fas fa-lock"></i>
          </span>
          {{-- Toggle mostrar/ocultar --}}
          <button type="button"
                  class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-orange-600 transition"
                  tabindex="-1"
                  aria-label="Mostrar u ocultar contraseña"
                  onclick="togglePasswordPro(this)">
            <i class="fas fa-eye" id="togglePwdIcon"></i>
          </button>
          <x-input-error :messages="$errors->get('password')" class="mt-2 text-sm text-red-600" />
        </div>

        {{-- Recordarme y Olvidé --}}
        <div class="flex items-center justify-between text-sm mt-2">
          <label class="inline-flex items-center text-gray-700 cursor-pointer select-none">
            <input type="checkbox" name="remember"
                   class="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded">
            <span class="ml-2">Recordarme</span>
          </label>
          @if (Route::has('password.request'))
            <a href="{{ route('password.request') }}"
               class="font-semibold text-orange-600 hover:text-orange-800 transition underline">¿Olvidaste tu contraseña?</a>
          @endif
        </div>

        {{-- Botón --}}
        <button type="submit" id="loginBtn"
                class="w-full py-3 bg-gradient-to-r from-orange-600 to-orange-800
                       text-white font-semibold rounded-lg shadow-lg
                       flex items-center justify-center gap-2
                       transform hover:-translate-y-0.5 hover:shadow-2xl
                       transition duration-200 focus:outline-none focus:ring-2 focus:ring-orange-500 text-lg">
          <span id="btnText">Entrar</span>
          <svg id="btnSpinner" class="hidden animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
          </svg>
        </button>
      </form>

      {{-- Branding mobile --}}
      <div class="block md:hidden mt-8 text-center text-xs text-gray-400">
        <span>Desarrollado por</span>
        <a href="https://publicidadenred.com" target="_blank" class="text-orange-700 underline font-semibold">Publicidad en Red</a>
      </div>
    </div>
  </main>

  {{-- FontAwesome CDN (quítalo si ya está en Vite) --}}
  <script src="https://kit.fontawesome.com/51be7268ba.js" crossorigin="anonymous"></script>
  <script>
    // Mostrar/Ocultar contraseña animado y accesible
    function togglePasswordPro(btn) {
      const input = document.getElementById('password');
      const icon = document.getElementById('togglePwdIcon');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
        btn.setAttribute('aria-label', 'Ocultar contraseña');
      } else {
        input.type = 'password';
        icon.classList.add('fa-eye');
        icon.classList.remove('fa-eye-slash');
        btn.setAttribute('aria-label', 'Mostrar contraseña');
      }
    }
    // Feedback loading al enviar
    document.getElementById('loginForm').addEventListener('submit', function () {
      document.getElementById('btnText').textContent = 'Ingresando...';
      document.getElementById('btnSpinner').classList.remove('hidden');
      document.getElementById('loginBtn').disabled = true;
    });
  </script>
</body>
</html>

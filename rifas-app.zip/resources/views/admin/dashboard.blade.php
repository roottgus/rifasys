@extends('layouts.admin')
@section('title', \App\Models\Setting::get('dashboard_title', 'Dashboard Administrativo'))

@section('content')
@php
    $primaryColor = \App\Models\Setting::get('empresa_color', '#ff7f00');
    $dashboardTitle = \App\Models\Setting::get('dashboard_title', 'Dashboard Administrativo');
@endphp

<div class="p-4 md:p-8 space-y-10 bg-gradient-to-br from-white via-gray-50 to-gray-100 rounded-3xl">

    {{-- Título principal --}}
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-4 gap-2">
        <h1 class="text-3xl md:text-4xl font-extrabold tracking-tight text-brand drop-shadow-sm" style="color: {{ $primaryColor }}">
            <i class="fas fa-chart-pie mr-3"></i>
            {{ $dashboardTitle }}
        </h1>
        <div class="flex items-center gap-2">
            <span class="inline-block bg-brand/10 text-brand font-bold px-3 py-1 rounded-lg text-xs" style="color: {{ $primaryColor }}; background: {{ $primaryColor }}11;">{{ date('d M Y') }}</span>
        </div>
    </div>

    {{-- Agrega separación superior y mayor separación inferior a los KPIs --}}
    <div class="mt-4">
        @include('admin.dashboard.partials._kpis')
    </div>

    {{-- SEPARADOR FIJO ENTRE SECCIONES --}}
    <div class="h-4 md:h-2 flex items-center justify-center">
        <div class="w-full h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>
    </div>

    <div>
        @include('admin.dashboard.partials._quick-actions')
    </div>

    {{-- ... demás partials ... --}}
    @include('admin.dashboard.partials._next-draw')
    <div class="mt-10">
        @include('admin.dashboard.partials._charts')
    </div>

    @include('admin.dashboard.partials._ultimos-tickets')
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  // Ventas Diarias
  const ventasCtx = document.getElementById('ventasDiariasChart').getContext('2d');
  new Chart(ventasCtx, {
    type: 'line',
    data: {
      labels: {!! json_encode($ventasFechas) !!},
      datasets: [{
        label: 'Ventas',
        data: {!! json_encode($ventasDatos) !!},
        fill: true,
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });

  // Abonos por Método
  const abonosCtx = document.getElementById('abonosMetodoChart').getContext('2d');
  new Chart(abonosCtx, {
    type: 'bar',
    data: {
      labels: {!! json_encode($metodosAbono) !!},
      datasets: [{
        label: 'Abonos',
        data: {!! json_encode($abonosDatos) !!},
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });
</script>
@endpush

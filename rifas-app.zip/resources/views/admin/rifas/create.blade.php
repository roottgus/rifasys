{{-- resources/views/admin/rifas/create.blade.php --}}
@extends('layouts.admin')
@section('title','Nueva Rifa')
@section('content')
  <div class="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow">
    <h1 class="text-2xl font-bold mb-6">Nueva Rifa</h1>

    <form action="{{ route('admin.rifas.store') }}"
          method="POST"
          enctype="multipart/form-data"
          class="space-y-6">
      @csrf
      @method('POST')

      {{-- 1) Campos básicos: nombre, descripción, precio, fecha/hora, etc --}}
      @include('admin.rifas._form_fields', [
        'rifa'         => null,
        'loterias'     => $loterias,
        'tiposLoteria' => $tiposLoteria,
      ])

      {{-- 2) Aquí incrustamos tu modal de premios especiales --}}
      @include('admin.rifas.partials._premios-modal', [
        'premios'      => old('premios', []),
        'loterias'     => $loterias,
        'tiposLoteria' => $tiposLoteria,
      ])

      {{-- 3) Botón de envío --}}
      <div class="flex justify-end">
        <button type="submit"
                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
          Crear Rifa
        </button>
      </div>
    </form>
  </div>
@endsection

{{-- 4) Asegurarnos de que Alpine conoce el componente --}}
@push('scripts')
<script>
  document.addEventListener('alpine:init', () => {
    // presupone que tu app.js ya expone globalmente `premiosModal`
    Alpine.data('premiosModal', window.premiosModal)
  })
</script>
@endpush

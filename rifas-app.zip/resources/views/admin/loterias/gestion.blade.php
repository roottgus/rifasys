@extends('layouts.admin')

@section('title', 'Gestión de Loterías')

@section('content')
<div x-data="gestionLoterias()" class="p-6 space-y-6">
  @include('admin.loterias.partials._banner')

  {{-- Feedback Toast --}}
  <template x-if="loteriaSuccess || tipoSuccess">
    <div 
      class="fixed top-6 right-6 z-50 bg-primary text-white px-6 py-3 rounded-lg shadow-lg flex items-center gap-2 animate-bounce"
      x-transition.opacity
    >
      <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
      </svg>
      <span x-text="loteriaSuccess || tipoSuccess"></span>
    </div>
  </template>

  {{-- Tarjetas superiores con counters --}}
  <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <div class="bg-primary/10 border-l-4 border-primary rounded-2xl p-4 flex items-center gap-4 shadow-sm">
      <i class="fas fa-dice fa-2x text-primary"></i>
      <div>
        <div class="font-bold text-lg text-primary">Loterías registradas</div>
        <div class="text-2xl font-extrabold text-gray-700" x-text="loteriasArray.length"></div>
      </div>
    </div>
    <div class="bg-emerald-100 border-l-4 border-emerald-400 rounded-2xl p-4 flex items-center gap-4 shadow-sm">
      <i class="fas fa-layer-group fa-2x text-emerald-600"></i>
      <div>
        <div class="font-bold text-lg text-emerald-600">Tipos de Lotería</div>
        <div class="text-2xl font-extrabold text-gray-700" x-text="tiposLoteria.length"></div>
      </div>
    </div>
  </div>

  {{-- Buscador de tipos de lotería --}}
  <div class="flex justify-end mt-2">
    <input type="text" x-model="searchTipo" placeholder="Buscar tipo de lotería..." 
      class="px-3 py-2 border rounded-xl w-80 focus:ring-primary focus:border-primary text-sm transition" />
  </div>

  <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
    {{-- Loterías --}}
    <div class="bg-white rounded-2xl shadow-lg p-4 border border-primary/10">
      <div class="flex items-center justify-between mb-3">
        <div class="font-bold text-orange-600 text-lg flex items-center gap-2">
          <i class="fas fa-dice"></i> Loterías Creadas
        </div>
        <button @click="openLoteriaModal = true" class="bg-primary hover:bg-primary/80 text-white px-3 py-1.5 rounded shadow flex items-center gap-1 text-sm transition">
          <i class="fas fa-plus-circle"></i> Nueva
        </button>
      </div>
      <template x-if="!loteriasArray.length">
        <div class="text-center text-gray-400 py-8">No hay loterías registradas.</div>
      </template>
      <template x-for="l in loteriasArray" :key="l.id">
        <div class="flex items-center justify-between px-4 py-2 rounded-xl border border-orange-100 bg-orange-50/80 mb-2 hover:shadow transition">
          <div class="flex items-center gap-2 font-semibold text-orange-700">
            <i class="fas fa-dice"></i> <span x-text="l.nombre"></span>
          </div>
          <div class="flex items-center gap-1">
            <button @click="openDeleteLoteriaModal(l)" class="text-red-500 hover:text-red-700 p-1" title="Eliminar"><i class="fas fa-trash"></i></button>
          </div>
        </div>
      </template>
    </div>

    {{-- Tipos de Lotería --}}
    <div class="bg-white rounded-2xl shadow-lg p-4 border border-emerald-100">
      <div class="flex items-center justify-between mb-3">
        <div class="font-bold text-emerald-700 text-lg flex items-center gap-2">
          <i class="fas fa-layer-group"></i> Tipos de Lotería Creados
        </div>
        <button @click="openTipoModal = true" class="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded shadow flex items-center gap-1 text-sm transition">
          <i class="fas fa-plus-circle"></i> Nuevo tipo
        </button>
      </div>
      <template x-if="!filteredTipos.length">
        <div class="text-center text-gray-400 py-8">No hay tipos registrados o no hay coincidencias.</div>
      </template>
      <template x-for="t in filteredTipos" :key="t.id">
        <div class="flex items-center justify-between px-4 py-2 rounded-xl border border-emerald-100 bg-emerald-50/70 mb-2 hover:shadow transition">
          <div>
            <span class="font-bold text-emerald-700" x-text="t.nombre"></span>
            <small class="ml-2 text-gray-500"><i class="fas fa-dice"></i> <span x-text="getLoteriaNombre(t.loteria_id)"></span></small>
          </div>
          <div class="flex items-center gap-1">
            <button @click="openDeleteTipoLoteriaModal(t)" class="text-red-500 hover:text-red-700 p-1" title="Eliminar"><i class="fas fa-trash"></i></button>
          </div>
        </div>
      </template>
    </div>
  </div>

  @include('admin.loterias.partials._modal-loteria')
  @include('admin.loterias.partials._modal-tipo-loteria')
  @include('admin.loterias.partials._modal-delete-loteria')
  @include('admin.loterias.partials._modal-delete-tipo')
</div>
@endsection

@push('styles')
<style>
  [x-cloak] { display: none !important; }
  .animate-bounce { animation: bounce 0.7s; }
  @keyframes bounce {
    0%   { transform: translateY(-30px); opacity: 0.7;}
    60%  { transform: translateY(6px);}
    90%  { transform: translateY(-2px);}
    100% { transform: translateY(0); opacity: 1;}
  }
</style>
@endpush

@push('scripts')
<script>
function gestionLoterias() {
  return {
    openLoteriaModal: false,
    openTipoModal: false,
    loterias: @json($loterias),
    tiposLoteria: @json($tiposLoteria->values()->toArray()),
    loteriaNombre: '',
    loteriaErrors: [],
    loteriaSuccess: '',
    tipoNombre: '',
    tipoLoteriaId: '',
    tipoErrors: [],
    tipoSuccess: '',
    searchTipo: '',

    // Computed
    get loteriasArray() {
      return Object.values(this.loterias).sort((a, b) => a.nombre.localeCompare(b.nombre));
    },
    get filteredTipos() {
      const q = (this.searchTipo || '').toLowerCase();
      return !q
        ? this.tiposLoteria
        : this.tiposLoteria.filter(t => t.nombre.toLowerCase().includes(q) || this.getLoteriaNombre(t.loteria_id).toLowerCase().includes(q));
    },
    getLoteriaNombre(id) {
      return this.loterias[id]?.nombre || '—';
    },

    // ... el resto de tus métodos originales abajo ...
    deleteLoteriaModal: false,
    loteriaToDelete: null,
    openDeleteLoteriaModal(loteria) { this.loteriaToDelete = loteria; this.deleteLoteriaModal = true; },
    confirmDeleteLoteria() {
      if (!this.loteriaToDelete) return;
      fetch(`/admin/loterias/${this.loteriaToDelete.id}`, {
        method: 'DELETE',
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' },
      }).then(async res => {
        if (res.ok) {
          delete this.loterias[this.loteriaToDelete.id];
          this.deleteLoteriaModal = false;
          this.loteriaToDelete = null;
          this.loteriaSuccess = '¡Lotería eliminada con éxito!';
          setTimeout(() => this.loteriaSuccess = '', 1800);
          this.reloadTiposLoteria();
        } else {
          this.loteriaSuccess = '';
          this.deleteLoteriaModal = false;
        }
      });
    },

    deleteTipoLoteriaModal: false,
    tipoLoteriaToDelete: null,
    openDeleteTipoLoteriaModal(tipo) { this.tipoLoteriaToDelete = tipo; this.deleteTipoLoteriaModal = true; },
    confirmDeleteTipoLoteria() {
      if (!this.tipoLoteriaToDelete) return;
      fetch(`/admin/tipos-loteria/${this.tipoLoteriaToDelete.id}`, {
        method: 'DELETE',
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' },
      }).then(async res => {
        if (res.ok) {
          this.tiposLoteria = this.tiposLoteria.filter(t => t.id !== this.tipoLoteriaToDelete.id);
          this.deleteTipoLoteriaModal = false;
          this.tipoLoteriaToDelete = null;
          this.tipoSuccess = '¡Tipo de lotería eliminado con éxito!';
          setTimeout(() => this.tipoSuccess = '', 1800);
        } else {
          this.tipoSuccess = '';
          this.deleteTipoLoteriaModal = false;
        }
      });
    },

    submitLoteria() {
      this.loteriaErrors = [];
      fetch('{{ route('admin.loterias.store') }}', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': '{{ csrf_token() }}',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ nombre: this.loteriaNombre })
      })
      .then(async res => {
        if (res.status === 422) {
          let data = await res.json();
          this.loteriaErrors = Object.values(data.errors).flat();
          return;
        }
        let data = await res.json();
        if (data.success) {
          this.loterias[data.loteria.id] = data.loteria;
          this.loteriaNombre = '';
          this.loteriaSuccess = '¡La lotería ha sido creada con éxito!';
          setTimeout(() => {
            this.loteriaSuccess = '';
            this.openLoteriaModal = false;
          }, 2000);
        }
      })
      .catch(() => {
        this.loteriaErrors = ['Error inesperado, intenta de nuevo.'];
      });
    },

    submitTipoLoteria() {
      this.tipoErrors = [];
      fetch('{{ route('admin.tipos-loteria.store') }}', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': '{{ csrf_token() }}',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          nombre: this.tipoNombre,
          loteria_id: this.tipoLoteriaId
        })
      })
      .then(async res => {
        if (res.status === 422) {
          let data = await res.json();
          this.tipoErrors = Object.values(data.errors).flat();
          return;
        }
        let data = await res.json();
        if (data.success) {
          this.tipoNombre = '';
          this.tipoLoteriaId = '';
          this.tipoSuccess = '¡El tipo de lotería ha sido creado con éxito!';
          this.reloadTiposLoteria();
          setTimeout(() => {
            this.tipoSuccess = '';
            this.openTipoModal = false;
          }, 2000);
        }
      })
      .catch(() => {
        this.tipoErrors = ['Error inesperado, intenta de nuevo.'];
      });
    },

    reloadTiposLoteria() {
      fetch('{{ route('admin.tipos-loteria.index') }}?ajax=1', {
        headers: { 'Accept': 'application/json' }
      })
      .then(r => r.json())
      .then(tipos => { this.tiposLoteria = tipos; });
    }
  }
}
</script>
@endpush

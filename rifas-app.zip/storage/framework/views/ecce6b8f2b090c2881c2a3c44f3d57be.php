

<?php $__env->startSection('title', 'Detalle de Rifa'); ?>

<?php $__env->startSection('content'); ?>
  
  <?php echo $__env->make('admin.rifas.partials._header', ['rifa' => $rifa], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  
  <?php echo $__env->make('admin.rifas.partials._ganador', ['rifa' => $rifa], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  
  <?php echo $__env->make('admin.rifas.partials._premios', ['rifa' => $rifa], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Main\rifas-app\resources\views/admin/rifas/show.blade.php ENDPATH**/ ?>
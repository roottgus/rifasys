<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login | <?php echo e(config('app.name')); ?></title>

  <!-- Tipografía moderna -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <style>
    body { font-family: 'Inter', sans-serif; }
    .fade-in { animation: fadeIn 0.7s cubic-bezier(.47,1.64,.41,.8) both; }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(32px);}
      to   { opacity: 1; transform: translateY(0);}
    }
    .input-error { border-color: #f87171 !important; }
    .input-icon { transition: color .2s; }
    .input:focus ~ .input-icon { color: #fb923c; }
  </style>
</head>
<body class="min-h-screen flex bg-gradient-to-br from-gray-100 to-orange-50">

  
  <aside class="hidden lg:flex w-1/2 relative overflow-hidden">
    <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('/images/login-bg.jpg');"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-orange-600/80 to-orange-900/80"></div>
    <div class="relative m-auto text-center px-12 fade-in text-white z-10">
      <img src="/images/logo.png" alt="Logo" class="mx-auto w-32 mb-6 drop-shadow-2xl">
      <h1 class="text-5xl font-extrabold mb-4 drop-shadow">Bienvenido</h1>
      <p class="text-xl font-medium drop-shadow">Gestiona tus rifas, tickets y pagos de forma rápida y segura.</p>
      <div class="mt-16 opacity-60 text-xs tracking-widest">Sistema Profesional de Gestión</div>
    </div>
  </aside>

  
  <main class="flex w-full lg:w-1/2 justify-center items-center p-4 sm:p-8">
    <div class="w-full max-w-md bg-white rounded-3xl shadow-2xl p-8 md:p-10 fade-in relative">

      <h2 class="text-3xl font-extrabold text-gray-800 mb-8 text-center tracking-tight">Iniciar Sesión</h2>

      <!-- Session Status -->
      <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>

      <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-6" id="loginForm" autocomplete="on">
        <?php echo csrf_field(); ?>

        
        <div class="relative">
          <label for="email" class="sr-only">Correo electrónico</label>
          <input
            id="email"
            name="email"
            type="email"
            required
            autofocus
            class="input w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg
                   focus:outline-none focus:ring-2 focus:ring-orange-500
                   transition-shadow duration-200 hover:shadow-md
                   <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            placeholder="Correo electrónico"
            autocomplete="username"
            aria-label="Correo electrónico"
          >
          <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none input-icon">
            <i class="fas fa-envelope"></i>
          </span>
          <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('email'),'class' => 'mt-2 text-sm text-red-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email')),'class' => 'mt-2 text-sm text-red-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>

        
        <div class="relative">
          <label for="password" class="sr-only">Contraseña</label>
          <input
            id="password"
            name="password"
            type="password"
            required
            class="input w-full pl-11 pr-12 py-3 border border-gray-300 rounded-lg
                   focus:outline-none focus:ring-2 focus:ring-orange-500
                   transition-shadow duration-200 hover:shadow-md
                   <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            placeholder="Contraseña"
            autocomplete="current-password"
            aria-label="Contraseña"
          >
          <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none input-icon">
            <i class="fas fa-lock"></i>
          </span>
          
          <button type="button"
                  class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-orange-600 transition"
                  tabindex="-1"
                  aria-label="Mostrar u ocultar contraseña"
                  onclick="togglePasswordPro(this)">
            <i class="fas fa-eye" id="togglePwdIcon"></i>
          </button>
          <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2 text-sm text-red-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2 text-sm text-red-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        </div>

        
        <div class="flex items-center justify-between text-sm mt-2">
          <label class="inline-flex items-center text-gray-700 cursor-pointer select-none">
            <input type="checkbox" name="remember"
                   class="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded">
            <span class="ml-2">Recordarme</span>
          </label>
          <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>"
               class="font-semibold text-orange-600 hover:text-orange-800 transition underline">¿Olvidaste tu contraseña?</a>
          <?php endif; ?>
        </div>

        
        <button type="submit" id="loginBtn"
                class="w-full py-3 bg-gradient-to-r from-orange-600 to-orange-800
                       text-white font-semibold rounded-lg shadow-lg
                       flex items-center justify-center gap-2
                       transform hover:-translate-y-0.5 hover:shadow-2xl
                       transition duration-200 focus:outline-none focus:ring-2 focus:ring-orange-500 text-lg">
          <span id="btnText">Entrar</span>
          <svg id="btnSpinner" class="hidden animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
          </svg>
        </button>
      </form>

      
      <div class="block md:hidden mt-8 text-center text-xs text-gray-400">
        <span>Desarrollado por</span>
        <a href="https://publicidadenred.com" target="_blank" class="text-orange-700 underline font-semibold">Publicidad en Red</a>
      </div>
    </div>
  </main>

  
  <script src="https://kit.fontawesome.com/51be7268ba.js" crossorigin="anonymous"></script>
  <script>
    // Mostrar/Ocultar contraseña animado y accesible
    function togglePasswordPro(btn) {
      const input = document.getElementById('password');
      const icon = document.getElementById('togglePwdIcon');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
        btn.setAttribute('aria-label', 'Ocultar contraseña');
      } else {
        input.type = 'password';
        icon.classList.add('fa-eye');
        icon.classList.remove('fa-eye-slash');
        btn.setAttribute('aria-label', 'Mostrar contraseña');
      }
    }
    // Feedback loading al enviar
    document.getElementById('loginForm').addEventListener('submit', function () {
      document.getElementById('btnText').textContent = 'Ingresando...';
      document.getElementById('btnSpinner').classList.remove('hidden');
      document.getElementById('loginBtn').disabled = true;
    });
  </script>
</body>
</html>
<?php /**PATH C:\Users\Main\rifas-app\resources\views/auth/login.blade.php ENDPATH**/ ?>
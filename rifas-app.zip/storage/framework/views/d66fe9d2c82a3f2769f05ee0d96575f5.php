

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="clientesPage()" class="p-6 space-y-6">
    <?php echo $__env->make('admin.clientes.partials._search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.clientes.partials._table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.clientes.partials._modal-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.clientes.partials._modal-tickets', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Store Alpine para clientes + modal tickets
function clientesPage() {
    return {
        // --- Modal de Cliente ---
        modalOpen: false,
        editMode: false,
        clienteId: null,
        nombre: '', cedula: '', email: '', telefono: '', direccion: '',
        mensajeCedula: '', mensajeEmail: '', mensajeTelefono: '',
        errors: {},
        loading: false,

        // --- Modal Tickets ---
        modalTicketsOpen: false,
        ticketsLoading: false,
        tickets: [],
        clienteTickets: null,
        // --- Profesional: compatibilidad con store modular ---
        cliente: null, // <= Así puedes importar un store o abrir el modal desde otra parte y nunca tendrás ReferenceError

        openModal(cliente = null) {
            this.editMode = !!cliente;
            this.clienteId = cliente?.id || null;
            this.nombre = cliente?.nombre || '';
            this.cedula = cliente?.cedula || '';
            this.email = cliente?.email || '';
            this.telefono = cliente?.telefono || '';
            this.direccion = cliente?.direccion || '';
            this.errors = {};
            this.mensajeCedula = '';
            this.mensajeEmail = '';
            this.mensajeTelefono = '';
            this.modalOpen = true;
        },
        closeModal() {
            this.modalOpen = false;
        },

        buscarCedula() {
            if (!this.cedula) return;
            fetch('/admin/clientes/validar-campo', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                body: JSON.stringify({ campo: 'cedula', valor: this.cedula }),
            })
            .then(r => r.json()).then(res => {
                this.mensajeCedula = res.message;
                if (res.exists && res.cliente) {
                    this.nombre = res.cliente.nombre || '';
                    this.email = res.cliente.email || '';
                    this.telefono = res.cliente.telefono || '';
                    this.direccion = res.cliente.direccion || '';
                }
            });
        },
        validarEmail() {
            if (!this.email) return;
            fetch('/admin/clientes/validar-campo', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                body: JSON.stringify({ campo: 'email', valor: this.email, cedula: this.cedula }),
            })
            .then(r => r.json()).then(res => {
                this.mensajeEmail = res.conflicto ? res.message : '';
            });
        },
        validarTelefono() {
            if (!this.telefono) return;
            fetch('/admin/clientes/validar-campo', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                body: JSON.stringify({ campo: 'telefono', valor: this.telefono, cedula: this.cedula }),
            })
            .then(r => r.json()).then(res => {
                this.mensajeTelefono = res.conflicto ? res.message : '';
            });
        },
        submit() {
            this.loading = true;
            this.errors = {};
            fetch(this.editMode ? `/admin/clientes/${this.clienteId}` : '/admin/clientes', {
                method: this.editMode ? 'PUT' : 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                body: JSON.stringify({
                    nombre: this.nombre,
                    cedula: this.cedula,
                    email: this.email,
                    telefono: this.telefono,
                    direccion: this.direccion,
                })
            })
            .then(async r => {
                this.loading = false;
                if (r.status === 422) {
                    this.errors = await r.json();
                } else if (r.ok) {
                    window.location.reload(); // Refresca la lista al guardar
                }
            });
        },

        // --------- Tickets de Cliente (AJAX Modal) ----------
        abrirModalTickets(cliente) {
            this.ticketsLoading = true;
            this.tickets = [];
            this.clienteTickets = null;
            // --- Limpia variable store para máxima compatibilidad ---
            this.cliente = null;

            this.modalTicketsOpen = true;
            fetch(`/admin/clientes/${cliente.id}/tickets-ajax`)
                .then(r => {
                    if (!r.ok) throw new Error('No se pudo cargar la información');
                    return r.json();
                })
                .then(res => {
                    this.tickets = res.tickets;
                    this.clienteTickets = res.cliente;
                    // --- Opcional: también rellena la variable store si la usas desde fuera
                    this.cliente = res.cliente;
                })
                .catch(e => {
                    this.tickets = [];
                    this.clienteTickets = null;
                    this.cliente = null;
                    alert(e.message || 'Error cargando tickets del cliente');
                })
                .finally(() => {
                    this.ticketsLoading = false;
                });
        },

        cerrarModalTickets() {
            this.modalTicketsOpen = false;
            this.tickets = [];
            this.clienteTickets = null;
            this.cliente = null;
        },
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Main\rifas-app\resources\views/admin/clientes/index.blade.php ENDPATH**/ ?>
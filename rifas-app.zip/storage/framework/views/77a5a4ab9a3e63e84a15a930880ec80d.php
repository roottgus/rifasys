
<?php $__env->startSection('title', \App\Models\Setting::get('dashboard_title', 'Dashboard Administrativo')); ?>

<?php $__env->startSection('content'); ?>
<?php
    $primaryColor = \App\Models\Setting::get('empresa_color', '#ff7f00');
    $dashboardTitle = \App\Models\Setting::get('dashboard_title', 'Dashboard Administrativo');
?>

<div class="p-4 md:p-8 space-y-10 bg-gradient-to-br from-white via-gray-50 to-gray-100 rounded-3xl">

    
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-4 gap-2">
        <h1 class="text-3xl md:text-4xl font-extrabold tracking-tight text-brand drop-shadow-sm" style="color: <?php echo e($primaryColor); ?>">
            <i class="fas fa-chart-pie mr-3"></i>
            <?php echo e($dashboardTitle); ?>

        </h1>
        <div class="flex items-center gap-2">
            <span class="inline-block bg-brand/10 text-brand font-bold px-3 py-1 rounded-lg text-xs" style="color: <?php echo e($primaryColor); ?>; background: <?php echo e($primaryColor); ?>11;"><?php echo e(date('d M Y')); ?></span>
        </div>
    </div>

    
    <div class="mt-4">
        <?php echo $__env->make('admin.dashboard.partials._kpis', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div class="h-4 md:h-2 flex items-center justify-center">
        <div class="w-full h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>
    </div>

    <div>
        <?php echo $__env->make('admin.dashboard.partials._quick-actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <?php echo $__env->make('admin.dashboard.partials._next-draw', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="mt-10">
        <?php echo $__env->make('admin.dashboard.partials._charts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <?php echo $__env->make('admin.dashboard.partials._ultimos-tickets', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  // Ventas Diarias
  const ventasCtx = document.getElementById('ventasDiariasChart').getContext('2d');
  new Chart(ventasCtx, {
    type: 'line',
    data: {
      labels: <?php echo json_encode($ventasFechas); ?>,
      datasets: [{
        label: 'Ventas',
        data: <?php echo json_encode($ventasDatos); ?>,
        fill: true,
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });

  // Abonos por Método
  const abonosCtx = document.getElementById('abonosMetodoChart').getContext('2d');
  new Chart(abonosCtx, {
    type: 'bar',
    data: {
      labels: <?php echo json_encode($metodosAbono); ?>,
      datasets: [{
        label: 'Abonos',
        data: <?php echo json_encode($abonosDatos); ?>,
        borderRadius: 4
      }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Main\rifas-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
<div x-data="formRifa()" x-init="initTipoLoteria()" class="space-y-5">

  
  <div>
    <label class="block text-sm font-semibold text-gray-700 mb-1">
      <i class="fas fa-heading mr-1 text-orange-400"></i> Nombre de la Rifa <span class="text-red-500">*</span>
    </label>
    <input type="text"
           name="nombre"
           value="<?php echo e(old('nombre', optional($rifa)->nombre)); ?>"
           class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 focus:ring-2 focus:ring-orange-100 transition"
           required
           placeholder="Ejemplo: Rifa de la Moto AKT 2024">
    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  
  <div>
    <label class="block text-sm font-semibold text-gray-700 mb-1">
      <i class="fas fa-align-left mr-1 text-orange-400"></i> Descripción
    </label>
    <textarea name="descripcion"
              class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 focus:ring-2 focus:ring-orange-100 transition"
              rows="2"
              placeholder="Breve detalle, reglas o premios destacados"><?php echo e(old('descripcion', optional($rifa)->descripcion)); ?></textarea>
    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  
  <div>
    <label class="block text-sm font-semibold text-gray-700 mb-1">
      <i class="fas fa-image mr-1 text-orange-400"></i> Imagen (opcional)
      <span class="text-gray-400 font-normal">(JPG, PNG, SVG máx. 2MB)</span>
    </label>
    <input type="file"
           name="imagen"
           class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 bg-white focus:ring-2 focus:ring-orange-100 transition">
    <?php if(optional($rifa)->imagen): ?>
      <div class="mt-2">
        <img src="<?php echo e(asset('storage/rifas/' . $rifa->imagen)); ?>"
             alt="Imagen actual"
             class="h-16 rounded shadow inline-block mr-2">
        <span class="text-xs text-gray-500">Imagen actual</span>
      </div>
    <?php endif; ?>
    <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    
    <div>
      <label class="block text-sm font-semibold text-gray-700 mb-1">
        <i class="fas fa-th-large mr-1 text-orange-400"></i> Lotería <span class="text-red-500">*</span>
      </label>
      <select x-model="loteria_id"
              @change="fetchTipos()"
              name="loteria_id"
              class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 focus:ring-2 focus:ring-orange-100 transition"
              required>
        <option value="">-- Selecciona --</option>
        <?php $__currentLoopData = $loterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($id); ?>"><?php echo e($nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['loteria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div>
      <label class="block text-sm font-semibold text-gray-700 mb-1">
        <i class="fas fa-list-ol mr-1 text-orange-400"></i> Tipo de Lotería <span class="text-red-500">*</span>
      </label>
      <select x-model="tipo_loteria_id"
              name="tipo_loteria_id"
              class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 focus:ring-2 focus:ring-orange-100 transition"
              :disabled="tipos.length === 0"
              required>
        <option value="">-- Selecciona --</option>
        <template x-for="tipo in tipos" :key="tipo.id">
          <option :value="tipo.id" x-text="tipo.nombre"></option>
        </template>
      </select>
      <?php $__errorArgs = ['tipo_loteria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    
    <div>
      <label class="block text-sm font-semibold text-gray-700 mb-1">
        <i class="fas fa-dollar-sign mr-1 text-orange-400"></i> Precio por ticket (USD) <span class="text-red-500">*</span>
      </label>
      <input type="number"
             name="precio"
             step="0.01"
             value="<?php echo e(old('precio', optional($rifa)->precio)); ?>"
             class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 focus:ring-2 focus:ring-orange-100 transition"
             required
             placeholder="Ej: 2.00">
      <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div>
      <label class="block text-sm font-semibold text-gray-700 mb-1">
        <i class="fas fa-list-ol mr-1 text-orange-400"></i> Cantidad de números <span class="text-red-500">*</span>
      </label>
      <input type="number"
             name="cantidad_numeros"
             min="1"
             value="<?php echo e(old('cantidad_numeros', optional($rifa)->cantidad_numeros ?? 100)); ?>"
             class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 focus:ring-2 focus:ring-orange-100 transition"
             required
             placeholder="Ej: 100">
      <?php $__errorArgs = ['cantidad_numeros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="grid grid-cols-2 gap-2">
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">
          <i class="fas fa-calendar-day mr-1 text-orange-400"></i> Fecha de sorteo <span class="text-red-500">*</span>
        </label>
        <input type="date"
               name="fecha_sorteo"
               value="<?php echo e(old('fecha_sorteo', optional($rifa)->fecha_sorteo)); ?>"
               class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 focus:ring-2 focus:ring-orange-100 transition"
               required>
        <?php $__errorArgs = ['fecha_sorteo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1">
          <i class="fas fa-clock mr-1 text-orange-400"></i> Hora de sorteo
        </label>
        <input type="time"
               name="hora_sorteo"
               value="<?php echo e(old('hora_sorteo', optional($rifa)->hora_sorteo)); ?>"
               class="w-full border border-orange-200 focus:border-orange-400 rounded-lg p-2 focus:ring-2 focus:ring-orange-100 transition">
        <?php $__errorArgs = ['hora_sorteo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="text-xs text-red-500 mt-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function formRifa() {
  return {
    loteria_id: '<?php echo e(old('loteria_id', optional($rifa)->loteria_id)); ?>',
    tipo_loteria_id: '<?php echo e(old('tipo_loteria_id', optional($rifa)->tipo_loteria_id)); ?>',
    tipos: [],
    fetchTipos() {
      if (!this.loteria_id) {
        this.tipos = [];
        this.tipo_loteria_id = '';
        return;
      }
      fetch(`/admin/loterias/${this.loteria_id}/tipos`)
        .then(res => res.json())
        .then(data => {
          this.tipos = data;
          if (!this.tipos.some(t => t.id == this.tipo_loteria_id)) {
            this.tipo_loteria_id = '';
          }
        });
    },
    initTipoLoteria() {
      if (this.loteria_id) {
        this.fetchTipos();
      }
    }
  }
}
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Main\rifas-app\resources\views/admin/rifas/_form_fields.blade.php ENDPATH**/ ?>
<div class="bg-white shadow-xl rounded-2xl overflow-hidden">
    <table class="w-full min-w-[700px]">
        <thead class="bg-gradient-to-r from-primary-50 to-blue-50">
            <tr>
                <th class="px-4 py-3 text-left text-sm font-bold text-gray-600">#</th>
                <th class="px-4 py-3 text-left text-sm font-bold text-gray-600">Nombre</th>
                <th class="px-4 py-3 text-left text-sm font-bold text-gray-600">Cédula</th>
                <th class="px-4 py-3 text-left text-sm font-bold text-gray-600">Email</th>
                <th class="px-4 py-3 text-left text-sm font-bold text-gray-600">Teléfono</th>
                <th class="px-4 py-3 text-left text-sm font-bold text-gray-600">Registrado</th>
                <th class="px-4 py-3 text-center text-sm font-bold text-gray-600">Tickets</th>
                <th class="px-4 py-3 text-right text-sm font-bold text-gray-600">Acciones</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-primary-50/40 transition">
                    <td class="px-4 py-3 text-gray-400 font-semibold"><?php echo e($cliente->id); ?></td>
                    <td class="px-4 py-3 font-bold text-gray-800"><?php echo e($cliente->nombre); ?></td>
                    <td class="px-4 py-3 text-gray-600"><?php echo e($cliente->cedula); ?></td>
                    <td class="px-4 py-3 text-blue-600"><?php echo e($cliente->email); ?></td>
                    <td class="px-4 py-3 text-gray-700"><?php echo e($cliente->telefono); ?></td>
                    <td class="px-4 py-3 text-xs text-gray-400"><?php echo e($cliente->created_at?->format('d M Y H:i')); ?></td>
                    <td class="px-4 py-3 text-center">
                        <button
    @click="abrirModalTickets({ id: <?php echo e($cliente->id); ?> })"
    class="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-700 rounded-full hover:bg-blue-200 text-xs font-semibold"
    title="Ver tickets de <?php echo e($cliente->nombre); ?>">
    <i class="fas fa-ticket-alt"></i>
    <?php echo e($cliente->tickets_count ?? 0); ?>

</button>

                        
                        
                    </td>
                    <td class="px-4 py-3 text-right space-x-1">
                        <button @click="openModal(<?php echo e($cliente->toJson()); ?>)"
                                class="inline-flex items-center gap-1 px-3 py-1 bg-primary-50 text-primary-700 rounded-full hover:bg-primary-100 transition"
                                title="Editar"><i class="fas fa-edit"></i></button>
                        <form action="<?php echo e(route('admin.clientes.destroy', $cliente)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('¿Eliminar este cliente?')"
                                    class="inline-flex items-center gap-1 px-3 py-1 bg-red-50 text-red-700 rounded-full hover:bg-red-100 transition"
                                    title="Eliminar"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="px-5 py-8 text-center text-gray-400">No hay clientes registrados.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="mt-4 px-4 pb-3">
        <?php echo e($clientes->withQueryString()->links()); ?>

    </div>
</div>
<?php /**PATH C:\Users\Main\rifas-app\resources\views/admin/clientes/partials/_table.blade.php ENDPATH**/ ?>
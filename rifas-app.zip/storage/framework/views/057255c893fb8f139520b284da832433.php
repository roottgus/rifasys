
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>

    <style>
    [x-cloak] { display: none !important; }
    </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(\App\Models\Setting::get('empresa_nombre', config('app.name'))); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

    
    <?php
        $favicon = \App\Models\Setting::get('empresa_favicon');
        $primaryColor = \App\Models\Setting::get('empresa_color', '#2563eb'); // INDIGO-600 por defecto
        $secondaryColor = '#64748b'; // slate-500 de Tailwind, como secundario
        $accentColor = '#38bdf8'; // sky-400 de Tailwind, para acentos
    ?>
    <?php if($favicon): ?>
        <link rel="icon" type="image/png" href="<?php echo e(asset('storage/logos/'.$favicon)); ?>">
    <?php endif; ?>

    
    <style>
        :root {
            --primary-color: <?php echo e($primaryColor); ?>;
            --secondary-color: <?php echo e($secondaryColor); ?>;
            --accent-color: <?php echo e($accentColor); ?>;
        }
        .bg-primary     { background: var(--primary-color) !important; }
        .text-primary   { color: var(--primary-color) !important; }
        .border-primary { border-color: var(--primary-color) !important; }
        .bg-secondary     { background: var(--secondary-color) !important; }
        .text-secondary   { color: var(--secondary-color) !important; }
        .border-secondary { border-color: var(--secondary-color) !important; }
        .bg-accent     { background: var(--accent-color) !important; }
        .text-accent   { color: var(--accent-color) !important; }
    </style>
</head>

<body x-data class="min-h-screen flex bg-gray-100">

  
  <aside class="w-64 bg-gradient-to-b from-white via-gray-50 to-gray-100 border-r border-gray-200 flex flex-col shadow-xl z-10 relative">
      
      <div class="h-20 flex items-center justify-center bg-white shadow-md relative">
          <?php
    $logo = \App\Models\Setting::get('empresa_logo');
    $empresa = \App\Models\Setting::get('empresa_nombre', config('app.name'));
    if ($logo && !str_starts_with($logo, 'logos/')) {
        $logo = 'logos/' . $logo;
    }
?>

<?php if($logo): ?>
    <a href="<?php echo e(route('admin.splash')); ?>">
        <img src="<?php echo e(asset('storage/' . $logo)); ?>"
             alt="Logo Empresa"
             class="h-14 max-w-[120px] object-contain drop-shadow-md transition hover:scale-105" />
    </a>
<?php else: ?>
    <a href="<?php echo e(route('admin.splash')); ?>" class="flex items-center gap-3 text-2xl font-bold text-primary tracking-wider hover:opacity-90 transition">
        <span>
            <i class="fa-solid fa-crown text-yellow-400 drop-shadow-md"></i>
        </span>
        <?php echo e($empresa); ?>

    </a>
<?php endif; ?>

          <span class="absolute top-2 right-4 bg-primary/10 text-primary text-xs px-2 py-1 rounded-full font-semibold shadow-sm">Admin</span>
      </div>

      <nav class="flex-1 overflow-y-auto py-6">
          <ul class="space-y-2 px-3">
              <li>
                  <a href="<?php echo e(route('admin.dashboard')); ?>"
                     class="group flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
                     <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-primary text-white shadow-lg' : 'text-gray-700 hover:bg-primary/10 hover:text-primary'); ?>">
                      <i class="fas fa-home text-lg group-hover:scale-110 transition"></i>
                      Dashboard
                  </a>
              </li>
              <li>
                  <a href="<?php echo e(route('admin.rifas.index')); ?>"
                     class="group flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
                     <?php echo e(request()->is('admin/rifas*') ? 'bg-primary text-white shadow-lg' : 'text-gray-700 hover:bg-primary/10 hover:text-primary'); ?>">
                      <i class="fas fa-ticket-alt text-lg group-hover:scale-110 transition"></i>
                      Gestión de Rifas
                  </a>
              </li>
              <li>
                  <a href="<?php echo e(route('admin.tickets.index')); ?>"
                     class="group flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
                     <?php echo e(request()->is('admin/tickets*') ? 'bg-primary text-white shadow-lg' : 'text-gray-700 hover:bg-primary/10 hover:text-primary'); ?>">
                      <i class="fas fa-shopping-cart text-lg group-hover:scale-110 transition"></i>
                      Gestión de Tickets
                  </a>
              </li>
              <li>
                  <a href="<?php echo e(route('admin.clientes.index')); ?>"
                     class="group flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
                     <?php echo e(request()->is('admin/clientes*') ? 'bg-primary text-white shadow-lg' : 'text-gray-700 hover:bg-primary/10 hover:text-primary'); ?>">
                      <i class="fas fa-users text-lg group-hover:scale-110 transition"></i>
                      Gestión de Clientes
                  </a>
              </li>
              <li>
                  <a href="<?php echo e(route('admin.loterias.gestion')); ?>"
                     class="group flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
                     <?php echo e(request()->is('admin/loterias*') ? 'bg-primary text-white shadow-lg' : 'text-gray-700 hover:bg-primary/10 hover:text-primary'); ?>">
                      <i class="fas fa-th-large text-lg group-hover:scale-110 transition"></i>
                      Gestión de Loterías
                  </a>
              </li>
              <li>
                  <a href="<?php echo e(route('admin.configuracion.empresa')); ?>"
                     class="group flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
                     <?php echo e(request()->is('admin/configuracion/empresa*') ? 'bg-primary text-white shadow-lg' : 'text-gray-700 hover:bg-primary/10 hover:text-primary'); ?>">
                      <i class="fas fa-building text-lg group-hover:scale-110 transition"></i>
                      Mi Empresa
                  </a>
              </li>
          </ul>
      </nav>

      <div class="px-6 pb-6 mt-auto">
          <div class="text-[11px] text-gray-400 text-center">
              &copy; <?php echo e(date('Y')); ?> <?php echo e($empresa); ?><br>
              Desarrollado por <span class="font-bold text-primary">Publicidad En Red</span>
          </div>
      </div>
  </aside>

  
  <div class="flex-1 flex flex-col">
    <header class="h-16 bg-white border-b border-gray-200 flex items-center px-6 relative">
    
    <div class="ml-auto">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="text-gray-600 hover:text-gray-800">Cerrar sesión</button>
        </form>
    </div>
</header>

    <main class="flex-1 overflow-y-auto px-6 py-4">
      <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>   
    <?php echo $__env->yieldPushContent('scripts'); ?>
  </div>
</body>
</html>
<?php /**PATH C:\Users\Main\rifas-app\resources\views/layouts/admin.blade.php ENDPATH**/ ?>
Ticket de Rifa - <?php echo e(config('app.name')); ?>


Rifa: <?php echo e($ticket->rifa->nombre); ?>

Ticket: <?php echo e(str_pad($ticket->numero, 3, '0', STR_PAD_LEFT)); ?>

Estado: <?php echo e(strtoupper($ticket->estado)); ?>


Cliente: <?php echo e($cliente->nombre); ?>

Teléfono: <?php echo e($cliente->telefono ?? '—'); ?>

Dirección: <?php echo e($cliente->direccion ?? '—'); ?>


Verifica tu ticket en:
<?php echo e(url('tickets/verificar/'.$ticket->uuid)); ?>


¡Gracias por tu compra!
<?php /**PATH C:\Users\Main\rifas-app\resources\views/emails/venta_ticket_plain.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use App\Models\Rifa;
use App\Models\Cliente;
use App\Models\Abono;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class TicketGestionController extends Controller
{
    /**
     * Muestra la vista principal de gestión de tickets (solo la vista, AJAX carga los tickets).
     */
    public function index(Request $request)
{
    // Puedes ordenar por nombre o por fecha
    $rifas = Rifa::orderBy('nombre')->get();

    // Pasa rifas a la vista principal
    return view('admin.tickets.index', compact('rifas'));
}


    /**
     * Listado dinámico de tickets (AJAX).
     */
   public function ajaxIndex(Request $request)
{
    $query = Ticket::with(['cliente', 'rifa'])->whereHas('rifa');

    // Nuevo: Filtra por rifa si está presente
    $rifa_id = $request->query('rifa_id');
    if ($rifa_id) {
        $query->where('rifa_id', $rifa_id);
    }

    // Filtros igual que en index
    $estado = $request->query('estado');
    if ($estado && in_array($estado, ['vendido', 'abonado', 'apartado', 'reservado'])) {
        $query->where('estado', $estado);
    } else {
        $query->whereIn('estado', ['vendido', 'abonado', 'apartado', 'reservado']);
    }

    $busqueda = $request->query('q');
    if ($busqueda) {
        $query->where(function ($q) use ($busqueda) {
            $q->whereHas('cliente', function ($sub) use ($busqueda) {
                $sub->where('nombre', 'like', "%$busqueda%")
                    ->orWhere('cedula', 'like', "%$busqueda%");
            })
            ->orWhere('numero', 'like', "%$busqueda%");
        });
    }

    $tickets = $query->orderBy('numero', 'asc')->get();

    return view('admin.tickets._tickets_list', compact('tickets'))->render();
}


    /**
     * Devuelve JSON con los tickets de una rifa.
     * Oculta el QR para evitar el error de Imagick durante listado.
     */
    public function ticketsJson(Rifa $rifa): JsonResponse
    {
        try {
            $count = $rifa->cantidad_numeros;

            if ($rifa->tickets()->count() !== $count) {
                $rifa->tickets()->delete();
                $padLen = strlen((string)($count - 1));
                for ($i = 0; $i < $count; $i++) {
                    $rifa->tickets()->create([
                        'numero'        => str_pad((string)$i, $padLen, '0', STR_PAD_LEFT),
                        'precio_ticket' => $rifa->precio,
                        'estado'        => 'disponible',
                    ]);
                }
            }

            $tickets = $rifa->tickets()
                ->leftJoin('clientes', 'tickets.cliente_id', '=', 'clientes.id')
                ->select(
                    'tickets.id',
                    'tickets.numero',
                    'tickets.estado',
                    'tickets.precio_ticket',
                    'tickets.uuid',
                    'clientes.nombre as cliente_nombre',
                    'clientes.direccion as cliente_direccion',
                    'clientes.telefono as cliente_telefono',
                    'clientes.cedula as cliente_cedula'
                )
                ->orderBy('tickets.numero')
                ->get();

            $ticketIds = $tickets->pluck('id')->all();
            $abonosPorTicket = DB::table('abonos')
                ->select('ticket_id', DB::raw('SUM(monto) as total_abonado'))
                ->whereIn('ticket_id', $ticketIds)
                ->groupBy('ticket_id')
                ->pluck('total_abonado', 'ticket_id')
                ->toArray();

            // Calcula total_abonado y oculta qr_code
            $tickets = $tickets->map(function ($t) use ($abonosPorTicket) {
                $t->total_abonado = (float) ($abonosPorTicket[$t->id] ?? 0);
                return $t->makeHidden('qr_code');
            });

            return response()->json($tickets);
        } catch (\Throwable $e) {
            Log::error('Error en ticketsJson: ' . $e->getMessage(), [
                'rifa_id' => $rifa->id,
                'trace'   => $e->getTraceAsString(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Error al cargar tickets: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Vende un ticket vía AJAX.
     */
    public function sell(Request $request, Ticket $ticket): JsonResponse
    {
        $data = $request->validate([
            'cliente' => ['required', 'string', 'max:150'],
        ]);
        $cliente = Cliente::firstOrCreate(
            ['nombre' => $data['cliente']],
            []
        );
        $ticket->cliente()->associate($cliente);
        $ticket->estado = 'vendido';
        $ticket->save();

        Abono::create([
            'ticket_id'   => $ticket->id,
            'monto'       => $ticket->precio_ticket,
            'metodo_pago' => 'efectivo',
        ]);

        return response()->json([
            'message'    => "Ticket #{$ticket->numero} vendido a {$cliente->nombre}.",
            'ticket_id'  => $ticket->id,
            'cliente_id' => $cliente->id,
            'estado'     => $ticket->estado,
        ]);
    }

    /**
     * Reserva un ticket.
     */
    public function reserve(Ticket $ticket)
    {
        if ($ticket->estado === 'vendido') {
            return back()->with('error', 'Este ticket ya está vendido y no puede reservarse.');
        }
        $ticket->update(['estado' => 'reservado']);

        Abono::create([
            'ticket_id'   => $ticket->id,
            'monto'       => 0,
            'metodo_pago' => 'reserva',
        ]);
        return back()->with('success', "Ticket #{$ticket->numero} reservado correctamente.");
    }
    

    /**
     * Genera PDF de un ticket.
     */
    public function pdf(Ticket $ticket)
    {
        $ticket->load('rifa', 'cliente', 'abonos');
        $abono = $ticket->abonos()->latest()->first();
        $esAbonado = $abono && $abono->monto > 0 && $abono->monto < $ticket->precio_ticket;
        $esVendido = $ticket->estado === 'vendido';
        $esReservado = $ticket->estado === 'reservado';

        $estadoLabel = match (true) {
            $esVendido     => 'TICKET VENDIDO',
            $esAbonado     => 'TICKET ABONADO',
            $esReservado   => 'TICKET RESERVADO',
            default        => strtoupper($ticket->estado),
        };

        $cliente = $ticket->cliente;
        $clienteNombre = $cliente->nombre ?? '—';
        $clienteTelefono = $cliente->telefono ?? '—';
        $clienteDireccion = $cliente->direccion ?? '—';

        $abonoInfo = $esAbonado ? [
            'fecha'  => $abono->created_at->format('d/m/Y H:i'),
            'monto'  => $abono->monto,
            'metodo' => $abono->metodo_pago,
        ] : null;

        $qr_svg = $ticket->qr_code;

        $pdf = Pdf::loadView('admin.tickets.ticket_pdf', [
            'ticket'          => $ticket,
            'estadoLabel'     => $estadoLabel,
            'clienteNombre'   => $clienteNombre,
            'clienteTelefono' => $clienteTelefono,
            'clienteDireccion'=> $clienteDireccion,
            'abonoInfo'       => $abonoInfo,
            'qr_svg'          => $qr_svg,
        ])
        ->setPaper('a5', 'landscape');

        return $pdf->download("ticket-{$ticket->numero}-{$ticket->estado}.pdf");
    }

    /**
     * Detalle JSON de un ticket para el modal.
     */
    public function detalleJson(Ticket $ticket)
{
    $ticket->load(['cliente', 'abonos', 'rifa.premiosEspeciales']);

    // Para abonos: monto como float (no formateado)
    $abonos = $ticket->abonos->sortByDesc('created_at')->map(fn($abono) => [
        'id'         => $abono->id,
        'metodo_pago'=> $abono->metodo_pago,
        'banco'      => $abono->banco ?? '—',
        'monto'      => (float) $abono->monto,
        'referencia' => $abono->referencia ?? '—',
        'fecha'      => $abono->created_at?->format('Y-m-d H:i:s') ?? '—',
    ])->values();

    $totalAbonado   = $ticket->abonos->sum('monto');
    $precioTicket   = $ticket->precio_ticket;
    $saldoPendiente = max(0, $precioTicket - $totalAbonado);

    // Para el formato del número
    $padLength = $ticket->rifa && $ticket->rifa->cantidad_numeros
        ? strlen((string) ($ticket->rifa->cantidad_numeros - 1))
        : 3;

    // Premios especiales (si el modal los muestra)
    $premios = method_exists($ticket, 'evaluacionPremiosEspeciales')
        ? $ticket->evaluacionPremiosEspeciales()
        : [];

    $codigoQR = $ticket->uuid ?? $ticket->id;
    $urlQR    = route('tickets.verificar', ['uuid' => $codigoQR]);

    return response()->json([
        'id'                => $ticket->id,
        'numero'            => $ticket->numero,
        'numero_formateado' => str_pad($ticket->numero, $padLength, '0', STR_PAD_LEFT),
        'pad_length'        => $padLength,
        'estado'            => $ticket->estado,
        'updated_at'        => $ticket->updated_at?->format('Y-m-d H:i:s'),
        'precio_ticket'     => $precioTicket,
        'total_abonado'     => $totalAbonado,
        'saldo_pendiente'   => $saldoPendiente,
        'cliente'           => $ticket->cliente?->only(['nombre','cedula','telefono','direccion']),
        'rifa'              => $ticket->rifa?->only(['nombre','fecha_sorteo','hora_sorteo']),
        'abonos'            => $abonos,
        'premios'           => $premios,
        'codigo_qr'         => $codigoQR,
        'url_qr'            => $urlQR,
    ]);
}

/**
     * GENERA Y DEVUELVE el código QR como PNG para un ticket.
     * Usado en el modal del detalle.
     */
    public function qr(Ticket $ticket)
{
    $codigoQR = $ticket->uuid ?? $ticket->id;
    $url = route('tickets.verificar', ['uuid' => $codigoQR]);
    return response(
        \QrCode::format('svg')->size(240)->generate($url)
    )->header('Content-Type', 'image/svg+xml');
}

public function show(Ticket $ticket)
{
    // Carga relaciones necesarias (solo las que existen)
    $ticket->load(['cliente', 'abonos', 'rifa.premiosEspeciales', 'rifa.loteria']); // <-- QUITAMOS 'rifa.tipo'

    $abonos = $ticket->abonos->sortByDesc('created_at');
    $totalAbonado   = $ticket->abonos->sum('monto');
    $precioTicket   = $ticket->precio_ticket;
    $saldoPendiente = max(0, $precioTicket - $totalAbonado);

    $padLength = $ticket->rifa && $ticket->rifa->cantidad_numeros
        ? strlen((string) ($ticket->rifa->cantidad_numeros - 1))
        : 3;

    $premios = method_exists($ticket, 'evaluacionPremiosEspeciales')
        ? $ticket->evaluacionPremiosEspeciales()
        : [];

    $codigoQR = $ticket->uuid ?? $ticket->id;
    $urlQR    = route('tickets.verificar', ['uuid' => $codigoQR]);
    $qr_svg   = \QrCode::format('svg')->size(180)->generate($urlQR);

    return view('admin.tickets.show', compact(
        'ticket', 'abonos', 'totalAbonado', 'precioTicket',
        'saldoPendiente', 'padLength', 'premios', 'codigoQR', 'urlQR', 'qr_svg'
    ));
}

public function abonar(Request $request, Ticket $ticket)
{
    // Carga abonos y calcula total abonado antes de procesar
    $ticket->load('abonos');
    $totalAbonado   = $ticket->abonos->sum('monto');
    $precioTicket   = $ticket->precio_ticket;
    $saldoPendiente = max(0, $precioTicket - $totalAbonado);

    // Si el ticket ya está pagado, prohíbe más abonos
    if ($saldoPendiente <= 0) {
        return back()->with('error', 'El ticket ya está pagado completamente. No puede registrar más abonos.');
    }

    // Validación
    $rules = [
        'monto'         => ['required', 'numeric', 'min:0.01', 'max:'.$saldoPendiente],
        'metodo_pago'   => ['required', 'string', 'max:30'],
        'referencia'    => ['nullable', 'string', 'max:100', 'required_unless:metodo_pago,Efectivo'],
        'banco'         => ['nullable', 'string', 'max:100'],
        'telefono'      => ['nullable', 'string', 'max:30'],
        'correo'        => ['nullable', 'string', 'max:100'],
        'cedula'        => ['nullable', 'string', 'max:30'],
        'fecha_pago'    => ['required', 'date'],
        'lugar_pago'    => ['nullable', 'string', 'max:50'],
        'nota'          => ['nullable', 'string', 'max:250'],
    ];

    $validated = $request->validate($rules);

    // Validación de referencia única (excepto efectivo)
    if (
        $request->metodo_pago !== 'Efectivo' &&
        !empty($request->referencia) &&
        Abono::where('referencia', $request->referencia)->exists()
    ) {
        return back()->withInput()->with('error', 'La referencia ya fue utilizada en otro abono.');
    }

    // Registrar abono
    $abono = new Abono();
    $abono->ticket_id    = $ticket->id;
    $abono->monto        = $validated['monto'];
    $abono->metodo_pago  = $validated['metodo_pago'];
    $abono->referencia   = $validated['referencia'] ?? null;
    $abono->banco        = $validated['banco'] ?? null;
    $abono->telefono     = $validated['telefono'] ?? null;
    $abono->correo       = $validated['correo'] ?? null;
    $abono->cedula       = $validated['cedula'] ?? null;
    $abono->fecha        = $validated['fecha_pago']; // <--- OJO: se guarda en 'fecha'
    $abono->lugar_pago   = $validated['lugar_pago'] ?? null;
    $abono->nota         = $validated['nota'] ?? null;
    $abono->save();

    // Actualiza estado del ticket si corresponde
    $totalAbonadoNuevo = $ticket->abonos()->sum('monto') + $abono->monto;
    if ($totalAbonadoNuevo >= $ticket->precio_ticket) {
        $ticket->estado = 'vendido';
        $ticket->save();
    } elseif ($totalAbonadoNuevo > 0) {
        $ticket->estado = 'abonado';
        $ticket->save();
    }

    return back()->with('success', '¡Abono registrado correctamente!');
}




}

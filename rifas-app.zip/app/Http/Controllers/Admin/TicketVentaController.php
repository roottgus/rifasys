<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Rifa;
use App\Models\PaymentMethod;
use App\Models\Ticket;
use App\Models\Cliente;
use App\Models\Abono;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Mail\VentaTicketMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

class TicketVentaController extends Controller
{
    /**
     * Pantalla de venta de tickets (con métodos de pago activos y rifas).
     */
    public function sale()
    {
        $rifas = Rifa::with([
            'loteria',
            'tipoLoteria',
            'premiosEspeciales.loteria',
            'premiosEspeciales.tipoLoteria',
        ])->orderBy('nombre')->get();

        $rifas = $rifas->map(function($rifa) {
            return [
                'id'               => $rifa->id,
                'nombre'           => $rifa->nombre,
                'precio'           => $rifa->precio ?? 0,
                'fecha_sorteo'     => $rifa->fecha_sorteo ? $rifa->fecha_sorteo->format('Y-m-d') : null,
                'hora_sorteo'      => $rifa->hora_sorteo ?? '',
                'cantidad_numeros' => $rifa->cantidad_numeros ?? 0,
                'loteria'          => $rifa->loteria ? [
                    'id'     => $rifa->loteria->id,
                    'nombre' => $rifa->loteria->nombre,
                ] : null,
                'tipo_loteria'     => $rifa->tipoLoteria ? [
                    'id'     => $rifa->tipoLoteria->id,
                    'nombre' => $rifa->tipoLoteria->nombre,
                ] : null,
                'premios_especiales' => $rifa->premiosEspeciales->map(function($p) {
                    return [
                        'id'               => $p->id,
                        'tipo_premio'      => $p->tipo_premio,
                        'monto'            => $p->monto,
                        'detalle_articulo' => $p->detalle_articulo,
                        'fecha_premio'     => $p->fecha_premio,
                        'hora_premio'      => $p->hora_premio,
                        'loteria'          => $p->loteria ? [
                            'id'     => $p->loteria->id,
                            'nombre' => $p->loteria->nombre,
                        ] : null,
                        'tipo_loteria'     => $p->tipoLoteria ? [
                            'id'     => $p->tipoLoteria->id,
                            'nombre' => $p->tipoLoteria->nombre,
                        ] : null,
                    ];
                })->toArray(),
            ];
        })->values();

        // Configuración de métodos de pago
        $configs = [
            'tran_bancaria_nacional' => [
                'icon'        => 'fas fa-university text-indigo-500',
                'descripcion' => 'Datos requeridos para transferencias en bancos nacionales.',
                'info'        => 'Solo cuentas a nombre de la empresa.',
                'fields'      => [
                    ['key'=>'banco',   'label'=>'Banco',        'placeholder'=>'Banco del Titular'],
                    ['key'=>'titular', 'label'=>'Titular',      'placeholder'=>'Nombre completo titular'],
                    ['key'=>'cuenta',  'label'=>'Cuenta o IBAN','placeholder'=>'Número de cuenta'],
                    ['key'=>'ci_rif',  'label'=>'CI/RIF Titular','placeholder'=>'V12345678 o J123456789'],
                ],
            ],
            'pago_efectivo' => [
                'icon'        => 'fas fa-money-bill-wave text-green-600',
                'descripcion' => 'Para cobros en efectivo en taquilla o punto de venta físico.',
                'info'        => 'Puedes describir ubicación o condiciones.',
                'fields'      => [
                    ['key'=>'detalle','label'=>'Descripción','placeholder'=>'Condiciones o lugar de pago'],
                ],
            ],
            'pago_movil' => [
                'icon'        => 'fas fa-mobile-alt text-orange-500',
                'descripcion' => 'Permite recibir pagos vía Pago Móvil nacional.',
                'info'        => 'Incluye número y datos del titular.',
                'fields'      => [
                    ['key'=>'banco',   'label'=>'Banco',         'placeholder'=>'Banco emisor'],
                    ['key'=>'telefono','label'=>'Teléfono Pago Móvil','placeholder'=>'0414xxxxxxx'],
                    ['key'=>'ci_rif',  'label'=>'CI/RIF Titular', 'placeholder'=>'V12345678'],
                ],
            ],
            'tran_bancaria_internacional' => [
                'icon'        => 'fas fa-globe text-indigo-400',
                'descripcion' => 'Configura transferencias desde bancos internacionales.',
                'info'        => 'Indica IBAN/SWIFT, banco y titular.',
                'fields'      => [
                    ['key'=>'banco',   'label'=>'Banco','placeholder'=>'Banco internacional'],
                    ['key'=>'titular', 'label'=>'Titular','placeholder'=>'Nombre completo titular'],
                    ['key'=>'cuenta',  'label'=>'Cuenta o IBAN','placeholder'=>'IBAN/SWIFT'],
                    ['key'=>'ci_rif',  'label'=>'CI/RIF Titular','placeholder'=>'Identificación'],
                ],
            ],
            'zelle' => [
                'icon'        => "<img src='/images/zelle.svg' alt='Zelle' class='w-8 h-8 inline-block' style='vertical-align:middle;'>",
                'descripcion' => 'Configura recepción de pagos a través de Zelle.',
                'info'        => 'Debe incluir email y nombre del titular.',
                'fields'      => [
                    ['key'=>'correo','label'=>'Correo Zelle', 'placeholder'=>'ejemplo@email.com'],
                    ['key'=>'titular','label'=>'Titular Zelle','placeholder'=>'Nombre completo titular'],
                ],
            ],
        ];

        $metodosPagoActivos = PaymentMethod::where('enabled', 1)
            ->orderBy('id')
            ->get()
            ->map(function($m) use ($configs) {
                $config = $configs[$m->key] ?? [
                    'icon'        => 'fas fa-credit-card text-gray-400',
                    'descripcion' => '',
                    'info'        => '',
                    'fields'      => [],
                ];
                $details = is_array($m->details)
                    ? $m->details
                    : (json_decode($m->details, true) ?: []);
                return [
                    'id'          => $m->id,
                    'key'         => $m->key,
                    'name'        => $m->name,
                    'alias'       => $m->alias ?? null,
                    'icon'        => $config['icon'],
                    'descripcion' => $config['descripcion'],
                    'info'        => $config['info'],
                    'fields'      => collect($config['fields'])->map(function($f) use ($details) {
                        $val = $details[$f['key']] ?? '';
                        return $f + ['value' => $val];
                    })->toArray(),
                ];
            })
            ->values();

        return view('admin.tickets.sale', [
            'rifas'              => $rifas,
            'metodosPagoActivos' => $metodosPagoActivos,
        ]);
    }

    /**
     * Procesar la venta (AJAX)
     */
    public function procesarVenta(Request $request)
    {
        try {
            $data = $request->validate([
                'ticket_id'        => 'required|integer|exists:tickets,id',
                'accion'           => 'required|in:vender,apartado,abono',
                'cliente.cedula'   => 'nullable|string|max:20',
                'cliente.nombre'   => 'required|string|max:150',
                'cliente.email'    => 'nullable|string|email|max:150',
                'cliente.telefono' => 'nullable|string|max:50',
                'cliente.direccion'=> 'nullable|string|max:150',
                'monto_abono'      => 'nullable|numeric|min:0',
                'metodo_pago'      => 'nullable|string|max:100',
                'pago_datos'       => 'nullable|array',
            ]);

            // 1. Validación de unicidad
            $cedula   = $data['cliente']['cedula'] ?? null;
            $email    = $data['cliente']['email'] ?? null;
            $telefono = $data['cliente']['telefono'] ?? null;

            if ($cedula) {
                $clienteCedula = Cliente::where('cedula', $cedula)->first();
                if ($clienteCedula && strtolower(trim($clienteCedula->nombre)) !== strtolower(trim($data['cliente']['nombre']))) {
                    return response()->json([
                        'success' => false,
                        'mensaje' => 'La cédula ingresada ya está registrada a nombre de: ' . $clienteCedula->nombre . '.',
                        'campo'   => 'cedula',
                    ]);
                }
            }

            if ($email) {
                $clienteEmail = Cliente::where('email', $email);
                if ($cedula) {
                    $clienteEmail = $clienteEmail->where(function($q) use ($cedula) {
                        $q->whereNull('cedula')->orWhere('cedula', '!=', $cedula);
                    });
                }
                $clienteEmail = $clienteEmail->first();
                if ($clienteEmail) {
                    return response()->json([
                        'success' => false,
                        'mensaje' => 'El correo electrónico ya está registrado a nombre de: ' . $clienteEmail->nombre . '.',
                        'campo'   => 'email',
                    ]);
                }
            }

            if ($telefono) {
                $clienteTel = Cliente::where('telefono', $telefono);
                if ($cedula) {
                    $clienteTel = $clienteTel->where(function($q) use ($cedula) {
                        $q->whereNull('cedula')->orWhere('cedula', '!=', $cedula);
                    });
                }
                $clienteTel = $clienteTel->first();
                if ($clienteTel) {
                    return response()->json([
                        'success' => false,
                        'mensaje' => 'El teléfono ya está registrado a nombre de: ' . $clienteTel->nombre . '.',
                        'campo'   => 'telefono',
                    ]);
                }
            }

            // 2. Crear o actualizar cliente
            $cliente = Cliente::updateOrCreate(
                ['cedula' => $cedula],
                [
                    'nombre'   => $data['cliente']['nombre'],
                    'email'    => $email,
                    'telefono' => $telefono,
                    'direccion'=> $data['cliente']['direccion'] ?? null,
                ]
            );

            // 3. Actualizar el ticket
            $ticket = Ticket::findOrFail($data['ticket_id']);
            $ticket->cliente()->associate($cliente);
            $ticket->estado = match($data['accion']) {
                'vender'   => 'vendido',
                'apartado' => 'reservado',
                'abono'    => 'abonado',
            };
            $ticket->save();

            // 4. Registrar abono/venta
            $monto  = $data['accion'] === 'vender'
                    ? $ticket->precio_ticket
                    : ($data['monto_abono'] ?? 0);

            $metodo = !empty($data['metodo_pago'])
                ? PaymentMethod::where('key', $data['metodo_pago'])->first()
                : null;

            $pago       = $data['pago_datos'] ?? [];
            $detailsArr = is_array($metodo->details ?? null)
                ? $metodo->details
                : json_decode($metodo->details ?? '{}', true);

            $bancoMetodo = $detailsArr['banco'] ?? null;
            $cuentaDestino = $this->formatearCuentaDestino($metodo, $detailsArr, $data['metodo_pago'] ?? '');

            Abono::create([
                'ticket_id'           => $ticket->id,
                'tipo'                => $data['accion'],
                'monto'               => $monto,
                'metodo_pago'         => $data['metodo_pago'] ?? 'efectivo',
                'telefono'            => $pago['telefono'] ?? null,
                'cedula'              => $pago['ci_rif'] ?? null,
                'titular'             => $pago['titular'] ?? null,
                'banco'               => $bancoMetodo,
                'referencia'          => $pago['referencia'] ?? ($pago['detalle'] ?? ($pago['correo'] ?? null)),
                'payment_method_id'   => $metodo->id ?? null,
                'cuenta_admin_destino'=> $cuentaDestino,
            ]);

            $ticket->refresh();

            // 5. Envío de correo
            $logoRifasys = \App\Models\Setting::get('empresa_logo');
            if ($logoRifasys && !str_starts_with($logoRifasys, 'logos/')) {
                $logoRifasys = 'logos/' . $logoRifasys;
            }
            $logo_url = $logoRifasys
                ? asset('storage/' . $logoRifasys)
                : asset('images/logo.png');

            if (!empty($cliente->email)) {
                try {
                    Mail::to($cliente->email)
                        ->cc('publienredca@gmail.com')
                        ->queue(new VentaTicketMail($ticket, $cliente, $logo_url));
                } catch (\Exception $e) {
                    Log::error('Error enviando correo de ticket: ' . $e->getMessage());
                }
            }

            return response()->json([
                'success' => true,
                'mensaje' => 'Venta registrada correctamente',
                'ticket'  => array_merge(
                    $ticket->toArray(),
                    ['qr_code' => $ticket->qr_code]
                ),
            ]);
        } catch (\Exception $e) {
            Log::error('Error procesarVenta: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'mensaje' => 'Error interno del servidor. Por favor inténtalo de nuevo más tarde.',
            ], 500);
        }
    }

    /**
     * Formatea la cadena para cuenta de destino según método.
     *
     * @param PaymentMethod|null $metodo
     * @param array $details
     * @param string $key
     * @return string
     */
    private function formatearCuentaDestino($metodo, array $details, string $key): string
    {
        if (!$metodo) {
            return '';
        }

        if ($key === 'zelle') {
            return sprintf(
                'Correo: %s | Titular: %s',
                $details['correo'] ?? '',
                $details['titular'] ?? ''
            );
        }

        return sprintf(
            'Banco: %s | Titular: %s | Cuenta: %s | CI/RIF: %s',
            $details['banco'] ?? '',
            $details['titular'] ?? '',
            $details['cuenta'] ?? '',
            $details['ci_rif'] ?? ''
        );
    }
}
